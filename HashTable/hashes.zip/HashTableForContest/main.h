//
//  main.h
//  HashTableForContest
//
//  Created by Александр Малышев on 28.03.15.
//  Copyright (c) 2015 SecurityQQ. All rights reserved.
//

#ifndef __HashTableForContest__main__
#define __HashTableForContest__main__

#include <stdio.h>

#endif /* defined(__HashTableForContest__main__) */
